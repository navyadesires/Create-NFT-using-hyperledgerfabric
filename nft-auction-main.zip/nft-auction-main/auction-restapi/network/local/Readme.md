## One step setup
We will be using HyperLedger Fabric 2.2.

To start a fresh blockchain network, create channels, 
installing and instantiating the chaincodes in one go, run `./start.sh`.
