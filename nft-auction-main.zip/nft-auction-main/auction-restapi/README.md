# REST API - Description

The REST API is the backend for the UI to interface with the backend and chaincode. The backend is written on Node.js with several endpoints defined for creating and updating data.