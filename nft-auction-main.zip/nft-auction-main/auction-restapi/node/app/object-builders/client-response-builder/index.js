
const successResponse = require('./successResponse');
const errorResponse = require('./errorResponse');

module.exports = {
    successResponse,
    errorResponse
};

